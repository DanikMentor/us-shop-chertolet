from flask import render_template, request, jsonify, session, redirect
import random
from app import app, models
import sqlite3
models.cr_d()

# Simple chat responses
CHAT_RESPONSES = {
    "hello": "Hello! How can I help you today?",
    "products": "We offer a wide range of products in Electronics, Furniture, Kitchen, and Office categories.",
    "price": "Prices range from low to high. Use the price filter to narrow down your search.",
    "shipping": "Shipping takes 3-5 business days. Free shipping on eligible orders.",
    "contact": "You can contact us at support@example.com or call +371 11 111 111.",
    "hours": "Our support is available Monday-Friday, 9AM-6PM.",
    "default": "I'm here to help! Try: hello, products, price, shipping, contact, hours."
}

DB_NAME = "data_b.db"
def add_user_to_db(login_flask, password_flask, Email_flask, number_flask):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO users (Login, Password, Mail, Phone_n, Num_i_p, Bonus)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (login_flask, password_flask, Email_flask, number_flask, "0", "0"))

    user_id = cursor.lastrowid 

    conn.commit()
    conn.close()
    return user_id

def get_db():
    conn = sqlite3.connect("data_b.db")
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def index():
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT DISTINCT Category FROM products")
        rows = cursor.fetchall()
        categories = [r["Category"] for r in rows if r["Category"] is not None]

        # fetch initial product list (most recent first)
        cursor.execute("SELECT * FROM products ORDER BY id DESC LIMIT 100")
        prod_rows = cursor.fetchall()
        products = []
        for r in prod_rows:
            products.append({
                "id": r["id"],
                "name": r["Pr_name"],
                "price": r["Price"],
                "category": r["Category"],
                "brand": r["Brand"],
                "date": r["Date"],
                "discount": r["Discount"],
                "description": r["DESCRIPTION"] if "DESCRIPTION" in r.keys() else ""
            })
    except Exception:
        categories = []
        products = []
    finally:
        conn.close()
    return render_template("home.html", categories=categories, products=products)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")


    login_flask = (request.form.get("name") or "").strip()
    Email_flask = (request.form.get("email") or "").strip().lower()
    number_flask = (request.form.get("phone") or "").strip()
    password_flask = (request.form.get("password") or "").strip()


    if not login_flask or not Email_flask or not password_flask:
        return render_template("register.html", error="Please fill in name, email and password.")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE lower(Mail) = ?", (Email_flask,))
        if cur.fetchone():
            conn.close()
            return render_template("register.html", error="Email is already registered.")
        conn.close()
    except Exception:
        pass

    try:
        user_id =  add_user_to_db(login_flask, password_flask, Email_flask, number_flask)
        session['user_id'] = user_id
        session['username'] = login_flask
        return redirect("/")

    except Exception:
        return render_template("register.html", error="Registration failed. Please try again.")

@app.route("/search", methods=["POST"])
def search():
    query = request.form.get("query", "").strip()
    category = request.form.get("category", "all")
    min_price = request.form.get("min_price", "").strip()
    max_price = request.form.get("max_price", "").strip()

    sql = "SELECT * FROM products WHERE 1=1"
    params = []

    if query:
        sql += " AND (Pr_name LIKE ? OR Brand LIKE ?)"
        like_q = f"%{query}%"
        params.extend([like_q, like_q])

    if category and category != "all":
        sql += " AND Category = ?"
        params.append(category)
    
    if min_price:
        try:
            float_min = float(min_price)
            sql += " AND CAST(Price AS REAL) >= ?"
            params.append(float_min)
        except ValueError:
            pass

    if max_price:
        try:
            float_max = float(max_price)
            sql += " AND CAST(Price AS REAL) <= ?"
            params.append(float_max)
        except ValueError:
            pass

    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute(sql, params)
        rows = cursor.fetchall()
    finally:
        conn.close()

    products = []
    for r in rows:
        products.append({
            "id": r["id"],
            "name": r["Pr_name"],
            "price": r["Price"],
            "category": r["Category"],
            "brand": r["Brand"],
            "date": r["Date"],
            "discount": r["Discount"],
            "description": r["DESCRIPTION"] if "DESCRIPTION" in r.keys() else ""
        })

    return jsonify({"products": products})

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    user_message = data.get("message", "") or ""
    user_message = user_message.lower().strip()

    # keyword matching
    response = CHAT_RESPONSES.get("default")
    for key in CHAT_RESPONSES:
        if key != "default" and key in user_message:
            response = CHAT_RESPONSES[key]
            break

    # Return response and available options
    return jsonify({"response": response, "options": list(CHAT_RESPONSES.keys())})

@app.route("/bonuses") 
def give_user_start_bonuses():
    username = session.get('username')
    conn = sqlite3.connect('data_b.db') 
    conn.row_factory = sqlite3.Row # Это позволит брать данные по имени колонки 
    cursor = conn.cursor()


    cursor.execute("UPDATE users SET Bonus = ? WHERE Login = ?", (50, username))
    cursor.execute("SELECT Bonus FROM users WHERE Login = ?", (username,))
    row = cursor.fetchone()
    
    conn.commit()
    conn.close()
    
    if row is not None:
        user_bonus = int(row["Bonus"])
    else:
        user_bonus = 0
        
    return render_template("bonuses.html",bonuses=user_bonus)

#login routes
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    name_flask = (request.form.get("name") or "").strip().lower()
    password_flask = (request.form.get("password") or "").strip()
    if not name_flask or not password_flask:
        return render_template("login.html", error="Please enter both name and password.")
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id, Password FROM users WHERE lower(Login) = ?", (name_flask,))
        row = cur.fetchone()
        conn.close()

        if row and row["Password"] == password_flask:
            session['user_id'] = row["id"]
            session['username'] = name_flask
            return redirect("/")
        else:
            return render_template("login.html", error="Invalid name or password.")
    except Exception:
        return render_template("login.html", error="An error occurred. Please try again.")
    
#logout route
@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect("/")

@app.route("/cart")
def cart():
    return render_template("cart.html")

#checkout routes
@app.route("/checkout")
def checkout():
    user = None
    user_id = session.get('user_id')
    
    if user_id:
        try:
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT Login, Mail, Phone_n FROM users WHERE id = ?", (user_id,))
            user = cursor.fetchone()
            conn.close()
        except Exception:
            user = None
    
    return render_template("checkout.html", user=user)

@app.route("/secret-info")
def secret_info(): 
    return render_template("secret-info.html")


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html", path=request.path), 404

#колесо максона
PRIZES = [
    {"id": 0, "label": "Бонус1", "weight": 10, "color": "#e74c3c"},
    {"id": 1, "label": "Бонус2", "weight": 10, "color": "#3498db"},
    {"id": 2, "label": "Бонус3", "weight": 10, "color": "#f1c40f"},
    {"id": 3, "label": "Бонус4", "weight": 10, "color": "#9b59b6"},
    {"id": 4, "label": "Бонус5", "weight": 10, "color": "#e67e22"},
    {"id": 5, "label": "Бонус6", "weight": 10, "color": "#95a5a6"},
    {"id": 6, "label": "Бонус7", "weight": 10, "color": "#2ecc71"},
    {"id": 7, "label": "Бонус8", "weight": 10, "color": "#1abc9c"},
]


def get_db_fortune():
    conn = sqlite3.connect("data_b.db")
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/fortune_wheel")
def fortune_wheel():
    if "username" not in session:
        return redirect("/register")
    return render_template("fortune_wheel.html", prizes=PRIZES)


@app.route("/get_wheel_bonuses")
def get_wheel_bonuses():
    username = session.get("username")
    conn = get_db_fortune()
    cur = conn.cursor()
    cur.execute("SELECT Bonus FROM users WHERE Login = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return jsonify({"bonuses": int(row["Bonus"]) if row else 0})


@app.route("/get_winner")
def get_winner():
    username = session.get("username")
    conn = get_db_fortune()
    cur = conn.cursor()

    cur.execute("SELECT Bonus FROM users WHERE Login = ?", (username,))
    row = cur.fetchone()

    if not row or int(row["Bonus"]) < 1:
        conn.close()
        return jsonify({"error": "Недостаточно бонусов"}), 400

    cur.execute(
        "UPDATE users SET Bonus = Bonus - 1 WHERE Login = ?",
        (username,)
    )
    conn.commit()
    conn.close()

    weights = [p["weight"] for p in PRIZES]
    winner = random.choices(PRIZES, weights=weights, k=1)[0]

    return jsonify({"winner": winner})

